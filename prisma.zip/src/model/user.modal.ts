export class UserDTO {
  id?: string;
  email!: string;
  password!: string;
  createdAt?: Date;
  updateAt?: Date;
}
